from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

quiz_data = [
    {"question": "What is the capital of France?", "options": ["Paris", "London", "Berlin", "Rome"], "answer": "Paris"},
    {"question": "Who wrote 'Romeo and Juliet'?", "options": ["Shakespeare", "Hemingway", "Tolkien", "Austen"], "answer": "Shakespeare"},
    {"question": "What is the largest planet in our solar system?", "options": ["Earth", "Jupiter", "Saturn", "Mars"], "answer": "Jupiter"},
    {"question": "What is the chemical symbol for water?", "options": ["O2", "H2O", "CO2", "NaCl"], "answer": "H2O"},
    {"question": "In which year did India get independence?", "options": ["1947", "1950", "1945", "1960"], "answer": "1947"},
    {"question": "Which language is used for web apps?", "options": ["Python", "HTML", "C++", "Java"], "answer": "HTML"},
    {"question": "Who painted the Mona Lisa?", "options": ["Van Gogh", "Picasso", "Leonardo da Vinci", "Michelangelo"], "answer": "Leonardo da Vinci"},
    {"question": "Which gas do plants absorb?", "options": ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], "answer": "Carbon Dioxide"},
    {"question": "What is 9 + 10?", "options": ["19", "20", "21", "18"], "answer": "19"},
    {"question": "Which country is known as the Land of Rising Sun?", "options": ["India", "Japan", "China", "Nepal"], "answer": "Japan"},
    {"question": "What is the speed of light?", "options": ["300,000 km/s", "150,000 km/s", "3,000 km/s", "30,000 km/s"], "answer": "300,000 km/s"},
    {"question": "Which planet is known as the Red Planet?", "options": ["Earth", "Mars", "Venus", "Mercury"], "answer": "Mars"},
    {"question": "What is the boiling point of water?", "options": ["90°C", "100°C", "80°C", "120°C"], "answer": "100°C"},
    {"question": "Who is known as the Father of Computers?", "options": ["Charles Babbage", "Alan Turing", "Steve Jobs", "Bill Gates"], "answer": "Charles Babbage"},
    {"question": "Which animal is known as the King of Jungle?", "options": ["Tiger", "Lion", "Elephant", "Bear"], "answer": "Lion"}
]

@app.route('/')
def index():
    return render_template_string("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz App</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #1e1e2f;
            color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 850px;
            margin: 30px auto;
            padding: 25px;
            background: #2e2e3e;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        }
        .title-box {
            text-align: center;
            padding: 15px;
            background: #673ab7;
            color: #fff;
            font-size: 28px;
            font-weight: bold;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .question {
            margin-bottom: 20px;
        }
        .options {
            list-style-type: none;
            padding: 0;
        }
        .options li {
            margin: 8px 0;
            background: #42425a;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .options li:hover {
            background: #61618c;
        }
        button {
            background-color: #03a9f4;
            color: white;
            padding: 10px 20px;
            border: none;
            margin: 15px 10px 0 0;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0288d1;
        }
        #result, #history {
            margin-top: 30px;
            padding: 15px;
            background: #4caf50;
            font-size: 18px;
            font-weight: bold;
            border-radius: 8px;
            text-align: center;
            color: #fff;
        }
        #history {
            background: #607d8b;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title-box">🌙 Simple Quiz App </div>
        <form id="quizForm"></form>
        <button type="submit" form="quizForm">Submit</button>
        <button onclick="retakeQuiz()">Retake Quiz</button>
        <div id="result"></div>
        <div id="history"></div>
    </div>

    <script>
        const form = document.getElementById('quizForm');
        const result = document.getElementById('result');
        const historyBox = document.getElementById('history');

        fetch('/get_quiz')
            .then(res => res.json())
            .then(data => {
                data.forEach((q, index) => {
                    const div = document.createElement('div');
                    div.classList.add('question');
                    div.innerHTML = '<p><strong>Q' + (index + 1) + ':</strong> ' + q.question + '</p>';
                    const ul = document.createElement('ul');
                    ul.classList.add('options');

                    q.options.forEach(option => {
                        const li = document.createElement('li');
                        const input = document.createElement('input');
                        input.type = 'radio';
                        input.name = 'question' + index;
                        input.value = option;
                        li.appendChild(input);
                        li.appendChild(document.createTextNode(' ' + option));
                        ul.appendChild(li);
                    });

                    div.appendChild(ul);
                    form.appendChild(div);
                });
            });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const answers = [];
            for (let i = 0; i < 15; i++) {
                const selected = document.querySelector('input[name="question' + i + '"]:checked');
                answers.push(selected ? selected.value : "");
            }

            fetch('/submit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ answers: answers })
            })
            .then(res => res.json())
            .then(data => {
                const msg = "🎉 You scored " + data.score + " out of " + data.total + "!";
                result.textContent = msg;

                // Save to localStorage
                let history = JSON.parse(localStorage.getItem("quizHistory")) || [];
                history.push(msg);
                localStorage.setItem("quizHistory", JSON.stringify(history));

                showHistory();
            });
        });

        function showHistory() {
            let history = JSON.parse(localStorage.getItem("quizHistory")) || [];
            historyBox.innerHTML = "<h3>📜 Score History</h3>" + history.map(score => `<p>${score}</p>`).join("");
        }

        function retakeQuiz() {
            form.reset();
            result.textContent = "";
        }

     window.onload = function () {
    localStorage.removeItem("quizHistory");  // ⬅️ Clears score history on refresh
    showHistory(); // Still calls the function to show now-empty history
};

    </script>
</body>
</html>
""")

@app.route('/get_quiz', methods=['GET'])
def get_quiz():
    return jsonify(quiz_data)

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    score = 0
    for i, user_answer in enumerate(data['answers']):
        if user_answer == quiz_data[i]['answer']:
            score += 1
    return jsonify({"score": score, "total": len(quiz_data)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
