document.addEventListener('DOMContentLoaded', function () {
    fetch('/get_quiz')
      .then(response => response.json())
      .then(data => {
        const quizContainer = document.getElementById('quiz-container');
        data.forEach((q, index) => {
          const questionElement = document.createElement('div');
          questionElement.innerHTML = `<p>${index + 1}. ${q.question}</p>`;
          
          q.options.forEach(option => {
            questionElement.innerHTML += `
              <input type="radio" name="question${index}" value="${option}"> ${option}<br>
            `;
          });
  
          quizContainer.appendChild(questionElement);
        });
      });
  
    document.getElementById('submit-btn').addEventListener('click', () => {
      const answers = [];
      document.querySelectorAll('[name^="question"]').forEach((el, index) => {
        if (el.checked) answers.push(el.value);
      });
  
      fetch('/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers })
      })
      .then(response => response.json())
      .then(result => {
        document.getElementById('result').innerText = `You scored ${result.score} out of ${result.total}`;
      });
    });
  });
  